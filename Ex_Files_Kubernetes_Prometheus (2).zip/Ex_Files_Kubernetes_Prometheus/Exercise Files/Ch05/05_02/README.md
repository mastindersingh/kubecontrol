# Grafana quickstart for prometheus
Quickly setup up grafana on a kuberntes cluster
 with integration with prometheus compiled from:

https://github.com/coreos/prometheus-operator/tree/master/contrib/kube-prometheus/manifests

We can launch this simply with:

kubectl create -f grafana.yml 
