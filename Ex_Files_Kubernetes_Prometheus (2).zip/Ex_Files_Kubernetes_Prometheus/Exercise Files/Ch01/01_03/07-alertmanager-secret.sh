kubectl create secret generic alertmanager-main --from-file=alertmanager.yaml
